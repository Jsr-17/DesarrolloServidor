
<?php
function analizaWC($frase)
{
    $data=str_word_count($frase);
    echo "<br>".$data;
};




?>