<?php

echo "<footer>Tu supermercado de confianza</footer>";