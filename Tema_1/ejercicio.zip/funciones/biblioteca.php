<?php
function suma($a, $b):int  {
    return $a + $b;
}
function resta($a, $b):int {
    return $a - $b;
}
function multiplicacion($a, $b):int {
    return $a * $b;
}
function division($a, $b):int {
    return $a / $b;
}
function modulo($a, $b):int {
    return $a % $b;
}