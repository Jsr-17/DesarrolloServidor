<?php

    $user=(string)$_POST['user'];
    $pass=(string)$_POST['pass'];



echo("No has podido iniciar correctamente la sesion");
echo(" </br>");


echo''.$user.''.$pass.'';
